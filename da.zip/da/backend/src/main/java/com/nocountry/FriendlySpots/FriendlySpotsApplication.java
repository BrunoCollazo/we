package com.nocountry.FriendlySpots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendlySpotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendlySpotsApplication.class, args);
	}

}
